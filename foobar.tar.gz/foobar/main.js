$(document).ready(function() {
	function checkControls()
	{
		if (isFirst)
			$('#previous').hide();
		else
			$('#previous').show();
		if (isLast)
			$('#next').hide();
		else
			$('#next').show();
	}
	
	var id = parseInt($('#id').html());
	var isFirst = false;
	var isLast = true;
	var transitionType = $('#transitionType').html();
	var transitionTime = parseInt($('#transitionTime').html());
	var fade = (transitionType == 1);
	var slide = (transitionType == 2);
	checkControls();

	$('#next').click(function()
	{
		loadIfPossible(1);
	});

	$('#previous').click(function()
	{
		loadIfPossible(-1);
	});

	function loadData(data)
	{
		isFirst = data.isFirst;
                isLast = data.isLast;
                checkControls();
                $('#author').html('<p>' + data.author + '</p>');
                $('#content').html('<p>' + data.content + '</p>');
                $('#id').html(data.id);
                $('#date').html(data.date);
	}

	function loadIfPossible(step)
	{
		if ((step == 1 && isLast) || (step == -1 && isFirst))
			return;
		id += step;
		$.ajax(
		{
			url: "getSingle.php?id=" + (id)
		}).done(function(data)
		{
			if (data.id == undefined)
			{
				loadIfPossible(step);
				return;
			}
			if (fade)
			{
				$('#myWrapper').fadeOut(transitionTime, function()
				{
					loadData(data);
					$('#myWrapper').fadeIn(transitionTime);	
				});
			}
			else if (slide)
			{
				$('#myWrapper').slideToggle(transitionTime, function()
				{
					loadData(data);
					$('#myWrapper').slideToggle(transitionTime);
				});
			}			
		});
	}

});
