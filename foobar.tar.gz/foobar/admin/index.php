<html>
<head>
	<meta charset="utf-8">
	<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php
include '../dbconfig.php';
$statement = 'SELECT * FROM `quotes` ORDER BY `date` DESC';
$result = @mysql_query($statement);?>
<div class="wrapper">
<?php
$id = '-1';
$author = '';
$content = '';
if (isset($_GET['id']))
{
	$st = 'SELECT * FROM quotes WHERE id='.$_GET['id'].' LIMIT 1';
	$r = mysql_query($st);
	$re = mysql_fetch_array($r);
	$author = $re['author'];
	$content = $re['content'];
	$id = $re['id'];
}
$conf = mysql_fetch_array(mysql_query('SELECT * FROM `conf`')); ?>
<div class="col-md-12">
<form method="POST" action="edit.php" role="form">
	<div class="form-group">
		<label for="content">Treść</label>
		<textarea name="content" class="form-control" rows="7"><?=$content;?></textarea>
	</div>
	<div class="form-group">
		<label for="author">Autor</label>
		<input type="text" name="author" value="<?=$author?>" class="form-control"/>
	</div>
	<input type="hidden" value="<?=$id?>" name="id"/>
		<button type="submit" class="btn btn-default">Zapisz</button>
</form>
<hr />
<form class="form-inline" role="form" method="POST" action="config.php">
	<div class="form-group">
		<label for="type">Typ przejścia:</label>
		<div class="radio">
			<input type="radio" name="type" value="1" <?=$conf['transitionType'] == 1 ? 'checked' : ''?>/>
			<label for="type">
				fade
			</label>
		</div>
		<div class="radio">
			<input type="radio" name="type" value="2" <?=$conf['transitionType'] == 2 ? 'checked' : ''?>/>
			<label for="type">slide </label>
		</div>
	</div>
	<div class="form-group">
		<label for="time">Czas przejścia (ms):</label>
		<input type="text" name="time" class="form-control" value="<?=$conf['transitionTime']?>"/>
	</div>
	<button type="submit" class="btn btn-default">Zapisz</button>
</form>
<table class="table">
<?php while($row = mysql_fetch_array($result)): ?>
	<tr>
		<td><?=$row['content']?></td>
		<td><?=$row['author']?></td>
		<td><a href="index.php?id=<?=$row['id']?>"><span class="glyphicon glyphicon-edit">&nbsp;</span></a></td>
		<td><a href="#" id="<?=$row['id']?>" class="remove"><span class="glyphicon glyphicon-remove">&nbsp;</span></a></td>
	</tr>
<?php endwhile?>
</table>
</div>
</div>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="admin.js"></script>
</body>
</html>
