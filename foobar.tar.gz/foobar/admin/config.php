<?php
	include '../dbconfig.php';
	$type = $_POST['type'];
	$type = $type == '1' ? 1 : 2;
	$time = $_POST['time'];
	$statement = "UPDATE `conf` SET transitionType='".$type."', transitionTime=".$time." WHERE 1 = 1";
	mysql_query($statement);
	header('Location: index.php');
?>
