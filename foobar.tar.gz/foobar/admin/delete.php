<?php
	include '../dbconfig.php';
	if (isset($_GET['id']))
	{
		$statement = 'DELETE FROM `quotes` WHERE `id`='.$_GET['id'];
		@mysql_query($statement);
	}
?>
