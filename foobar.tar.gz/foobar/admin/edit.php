<?php
	include '../dbconfig.php';
	$id = $_POST['id'];
	$content = $_POST['content'];
	$author = $_POST['author'];
	$statement = '';
	if ($id == '-1' || $id == '')
		$statement = "INSERT INTO `quotes` (`author`, `content`) VALUES ('".$_POST['author']."', '".$_POST['content']."');";
	else
		$statement = "UPDATE `quotes` SET `author`='".$_POST['author']."', `content`='".$_POST['content']."' WHERE `id`=".$_POST['id'];
	@mysql_query($statement);
	header('Location: index.php');
?>
