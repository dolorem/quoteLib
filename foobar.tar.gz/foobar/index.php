<html>
<head>
	<meta charset="utf-8">
	<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php
include 'dbconfig.php';
$statement = 'SELECT * FROM `quotes` ORDER BY `date` DESC LIMIT 1';
$result = @mysql_query($statement);
$row = mysql_fetch_array($result);
$s = 'SELECT * FROM `conf` LIMIT 1;';
$res = mysql_query($s);
$transition = mysql_fetch_array($res);
?>

<div id="myWrapper">
	<div id="content">
		<p><?=$row['content']; ?></p>
	</div>
	<div id="author">
		<p><?=$row['author']; ?></p>
	</div>
	<div id="id">
		<?=$row['id']; ?>
	</div>
	<div id="controls">
		<a href="#" id="previous"><span class="glyphicon glyphicon-arrow-left">&nbsp;</span></a>
		<a href="#" id="next"><span class="glyphicon glyphicon-arrow-right">&nbsp;</span></a>
	</div>
	<div class="hidden">
		<div id="transitionTime"><?=$transition['transitionTime']?></div>
		<div id="transitionType"><?=$transition['transitionType']?></div>
	</div>
</div>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="main.js"></script>
<style>
@font-face
{
	font-family: "BravoRG";
	src: url('BravoRG.otf');
}
#id
{
	display: none;
}
#content
{
	font-family: "BravoRG";
	font-size: 80px;
	display: table;
	height: 75%;
	width: 100%;
}

#content p
{
	display: table-cell;
	vertical-align: middle;
	text-align: center;
}
#author
{
        font-family: "BravoRG";
        font-size: 30px;
        display: table;
        height: 25%;
        width: 100%;
	padding-right: 10%;
}

#author p
{
        display: table-cell;
        vertical-align: top;
        text-align: right;
}
#myWrapper
{
	height: 100%;
}
#controls
{
	position: absolute;
	top: 95%;
	right: 5%;
}
</style>
</body>
</html>
