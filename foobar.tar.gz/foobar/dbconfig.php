<?php
$server = @mysql_connect('localhost', 'root', 'toor');
$db = @mysql_select_db('foobar');
mysql_query('SET NAMES utf8');

