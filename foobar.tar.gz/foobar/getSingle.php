<?php
	include('dbconfig.php');
	$statement = '';
	if (isset($_GET['id']))
		$statement = 'SELECT * FROM `quotes` WHERE `id`='.intval($_GET['id']).' LIMIT 1';
	else
		$statement = 'SELECT * FROM `quotes` ORDER BY `date` DESC LIMIT 1';
	$result = @mysql_query($statement);
	$row = mysql_fetch_array($result);
	$first = false;
	$last = false;
	$statementForAll = 'SELECT * FROM `quotes` ORDER BY `id` ASC';
	$firstStatement = 'SELECT * FROM `quotes` ORDER BY `id` ASC LIMIT 1';
	$lastStatement = 'SELECT * FROM `quotes` ORDER BY `id` DESC LIMIT 1';
	if ($row == mysql_fetch_array(@mysql_query($firstStatement)))
		$first = true;
	if ($row == mysql_fetch_array(@mysql_query($lastStatement)))
		$last = true;
	$row['isFirst'] = $first;
	$row['isLast'] = $last;
	header('Content-type: text/json; charset=utf-8');
	echo json_encode($row);
